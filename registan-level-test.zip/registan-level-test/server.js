'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const cfg = require('./config');
const QRCode = require('./vendor/QRCode'), QRLevel = require('./vendor/QRCode/QRErrorCorrectLevel'); // MIT, see vendor/QRCode/LICENSE.txt
function qrSvg(text) {
  const q = new QRCode(-1, QRLevel.M); q.addData(text); q.make();
  const n = q.getModuleCount(), m = 4; let d = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += 'M' + (c + m) + ' ' + (r + m) + 'h1v1h-1z';
  const size = n + 2 * m;
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + size + ' ' + size + '" shape-rendering="crispEdges"><rect width="' + size + '" height="' + size + '" fill="#fff"/><path d="' + d + '" fill="#1A1A1A"/></svg>';
}

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const HOUR = 3600e3;

/* ---------- admin credentials (checked on the server only) ---------- */
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
let ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
if (!ADMIN_PASSWORD) {
  ADMIN_PASSWORD = crypto.randomBytes(9).toString('base64url');
  console.log('ADMIN_PASSWORD is not set. Temporary admin password for this run: ' + ADMIN_PASSWORD);
}
const SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const SALT = crypto.randomBytes(16);
const hashPw = (p) => crypto.scryptSync(String(p), SALT, 32);
const PW_HASH = hashPw(ADMIN_PASSWORD);
const USER_HASH = hashPw('u:' + ADMIN_USER);
const safeEq = (a, b) => a.length === b.length && crypto.timingSafeEqual(a, b);
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

/* ---------- data store (JSON file, atomic writes) ---------- */
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_FILE = path.join(DATA_DIR, 'db.json');
let db = { tokens: {}, attempts: {} };
try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch (e) { /* first run */ }
db.tokens = db.tokens || {}; db.attempts = db.attempts || {};
let saveTimer = null;
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    const tmp = DB_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, DB_FILE);
  }, 200);
}

/* ---------- question banks ---------- */
const BANKS = {};
for (const id of Object.keys(cfg.LEVELS)) {
  try { BANKS[id] = JSON.parse(fs.readFileSync(path.join(__dirname, 'questions', id + '.json'), 'utf8')); }
  catch (e) { BANKS[id] = []; }
}
const qIndex = {};
for (const id of Object.keys(BANKS)) for (const q of BANKS[id]) qIndex[q.id] = q;
const levelEnabled = (id) => !!cfg.LEVELS[id] && BANKS[id].length > 0;

/* ---------- helpers ---------- */
const shuffle = (a) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = crypto.randomInt(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
function send(res, code, obj, extra) {
  const body = JSON.stringify(obj);
  res.writeHead(code, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, extra || {}));
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', (c) => { n += c.length; if (n > 50e3) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}
const ip = (req) => String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now(); const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
  arr.push(now); hits.set(key, arr); return arr.length > max;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (!v.some((t) => now - t < 3600e3)) hits.delete(k); }, 600e3).unref();

function parseCookies(req) {
  const o = {}; String(req.headers.cookie || '').split(';').forEach((p) => { const i = p.indexOf('='); if (i > 0) o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return o;
}
const sign = (s) => crypto.createHmac('sha256', SECRET).update(s).digest('base64url');
function makeSession() { const p = Buffer.from(JSON.stringify({ exp: Date.now() + cfg.SESSION_HOURS * HOUR })).toString('base64url'); return p + '.' + sign(p); }
function isAdmin(req) {
  const c = parseCookies(req).sid; if (!c) return false;
  const [p, sig] = c.split('.'); if (!p || !sig) return false;
  const good = sign(p); if (sig.length !== good.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good))) return false;
  try { return JSON.parse(Buffer.from(p, 'base64url').toString()).exp > Date.now(); } catch (e) { return false; }
}
const isHttps = (req) => (req.headers['x-forwarded-proto'] || '').split(',')[0] === 'https' || !!req.socket.encrypted;
function cookie(req, val, maxAgeSec) {
  return 'sid=' + encodeURIComponent(val) + '; HttpOnly; SameSite=Lax; Path=/; Max-Age=' + maxAgeSec + (isHttps(req) ? '; Secure' : '');
}
function baseUrl(req) {
  if (process.env.PUBLIC_URL) return process.env.PUBLIC_URL.replace(/\/+$/, '');
  const proto = (req.headers['x-forwarded-proto'] || 'http').split(',')[0];
  return proto + '://' + req.headers.host;
}

/* ---------- test logic ---------- */
const STATUS = { in_progress: 'In progress', submitted: 'Submitted', left: 'Ended: left page', expired: 'Time expired' };
function groupFor(level, score, total) {
  const pct = total ? (score / total) * 100 : 0; let label = '-';
  for (const b of cfg.BANDS[level] || []) if (pct >= b.minPct) label = b.label;
  return label;
}
function finalize(att, status, when) {
  if (att.status !== 'in_progress') return;
  let score = 0;
  for (const o of att.order) if (att.answers[o.qid] === qIndex[o.qid].a) score++;
  att.score = score; att.total = att.order.length; att.status = status;
  att.finishedAt = status === 'expired' ? att.endsAt : Math.min(when || Date.now(), att.endsAt);
  save();
}
const result = (att) => ({ finished: true, name: att.name, score: att.score, total: att.total, status: att.status, statusLabel: STATUS[att.status] });
function expireIfNeeded(att) { if (att.status === 'in_progress' && Date.now() > att.endsAt + cfg.GRACE_SECONDS * 1000) finalize(att, 'expired'); }
function payload(att) {
  return {
    attemptId: att.id, endsAt: att.endsAt, serverNow: Date.now(), answers: att.answers, name: att.name,
    questions: att.order.map((o) => {
      const q = qIndex[o.qid];
      const r = { id: q.id, q: q.q, o: o.perm.map((i) => ({ i, t: q.o[i] })) };
      if (q.p) r.p = q.p; return r;
    }),
  };
}
function buildOrder(level) {
  // keep questions that share a reading passage together
  const units = []; const byP = new Map();
  for (const q of BANKS[level]) {
    if (q.p) { if (!byP.has(q.p)) { const u = []; byP.set(q.p, u); units.push(u); } byP.get(q.p).push(q); }
    else units.push([q]);
  }
  return shuffle(units).flat().map((q) => ({ qid: q.id, perm: shuffle(q.o.map((_, i) => i)) }));
}
const nameOk = (v) => /^\p{L}[\p{L}'’-]+(\s+\p{L}[\p{L}'’-]+)+$/u.test(String(v || '').trim()) && String(v).length <= 80;
const phoneOk = (v) => /^\+998 \(\d{2}\) \d{3}-\d{2}-\d{2}$/.test(String(v || ''));
const tokenOk = (t) => /^[A-Za-z0-9_-]{32}$/.test(t || '');
const tokenState = (t) => {
  const r = db.tokens[t]; if (!r) return 'invalid';
  if (r.status === 'used') return 'used';
  if (r.status === 'revoked') return 'invalid';
  if (Date.now() - r.created > cfg.TOKEN_TTL_HOURS * HOUR) return 'invalid';
  return 'ready';
};

function adminRows() {
  return Object.values(db.attempts).sort((a, b) => b.startedAt - a.startedAt).map((a) => {
    expireIfNeeded(a);
    const done = a.status !== 'in_progress';
    return {
      id: a.id, name: a.name, phone: a.phone, level: a.level, levelName: cfg.LEVELS[a.level].name,
      status: a.status, statusLabel: STATUS[a.status], score: done ? a.score : null, total: a.order.length,
      group: done ? groupFor(a.level, a.score, a.total) : '-', spentSec: done ? Math.round((a.finishedAt - a.startedAt) / 1000) : null,
      startedAt: a.startedAt, violations: (a.violations || []).length,
    };
  });
}
const csvCell = (v) => { v = String(v == null ? '' : v); if (/^(=|@|\t|\r|[+-](?!\d))/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; };

/* ---------- routes ---------- */
async function api(req, res, url) {
  const m = req.method, p = url.pathname;
  if ((m === 'POST' || m === 'DELETE') && req.headers.origin) {
    let h = ''; try { h = new URL(req.headers.origin).host; } catch (e) { /* ignore */ }
    if (h !== req.headers.host) return send(res, 403, { error: 'forbidden' });
  }
  let body = {};
  if (m === 'POST') {
    if (!String(req.headers['content-type'] || '').includes('application/json')) return send(res, 415, { error: 'json only' });
    try { body = await readBody(req); } catch (e) { return send(res, 400, { error: 'bad request' }); }
  }
  let x;

  if (m === 'GET' && p === '/api/levels') {
    return send(res, 200, Object.keys(cfg.LEVELS).map((id) => ({ id, name: cfg.LEVELS[id].name, minutes: cfg.LEVELS[id].minutes, count: BANKS[id].length, enabled: levelEnabled(id) })));
  }

  /* --- test taker --- */
  if ((x = p.match(/^\/api\/t\/([^/]+)$/)) && m === 'GET') {
    if (limited('tk:' + ip(req), 60, 60e3)) return send(res, 429, { error: 'too many requests' });
    if (!tokenOk(x[1])) return send(res, 404, { status: 'invalid' });
    const st = tokenState(x[1]); if (st !== 'ready') return send(res, 200, { status: st });
    const lv = db.tokens[x[1]].level;
    return send(res, 200, { status: 'ready', level: lv, levelName: cfg.LEVELS[lv].name, minutes: cfg.LEVELS[lv].minutes, count: BANKS[lv].length });
  }
  if ((x = p.match(/^\/api\/t\/([^/]+)\/start$/)) && m === 'POST') {
    if (limited('st:' + ip(req), 30, 60e3)) return send(res, 429, { error: 'too many requests' });
    if (!tokenOk(x[1])) return send(res, 404, { status: 'invalid' });
    if (!nameOk(body.name)) return send(res, 400, { error: 'name' });
    if (!phoneOk(body.phone)) return send(res, 400, { error: 'phone' });
    const st = tokenState(x[1]); if (st !== 'ready') return send(res, 410, { status: st });
    const rec = db.tokens[x[1]];
    if (!levelEnabled(rec.level)) return send(res, 409, { error: 'level not available' });
    const id = crypto.randomBytes(9).toString('base64url'), key = crypto.randomBytes(24).toString('base64url'), now = Date.now();
    const att = { id, token: x[1], level: rec.level, name: String(body.name).trim().replace(/\s+/g, ' '), phone: body.phone, keyHash: sha(key),
      startedAt: now, endsAt: now + cfg.LEVELS[rec.level].minutes * 60e3, status: 'in_progress', order: buildOrder(rec.level), answers: {}, violations: [] };
    rec.status = 'used'; rec.usedAt = now; rec.attemptId = id; // marked used at the moment the test starts
    db.attempts[id] = att; save();
    return send(res, 200, Object.assign({ key, minutes: cfg.LEVELS[rec.level].minutes }, payload(att)));
  }
  if ((x = p.match(/^\/api\/attempt\/([^/]+)(?:\/(answer|submit|violation))?$/))) {
    const att = db.attempts[x[1]];
    const key = m === 'GET' ? url.searchParams.get('key') : body.key;
    if (!att || !key || sha(key) !== att.keyHash) return send(res, 404, { error: 'not found' });
    expireIfNeeded(att);
    if (m === 'GET' && !x[2]) return send(res, 200, att.status === 'in_progress' ? payload(att) : result(att));
    if (m === 'POST' && x[2] === 'answer') {
      if (att.status !== 'in_progress') return send(res, 200, result(att));
      const q = qIndex[body.qid];
      if (q && att.order.some((o) => o.qid === q.id) && Number.isInteger(body.i) && body.i >= 0 && body.i < q.o.length) { att.answers[q.id] = body.i; save(); }
      return send(res, 200, { ok: true });
    }
    if (m === 'POST' && x[2] === 'violation') {
      if (att.status === 'in_progress' && att.violations.length < 50) { att.violations.push({ t: Date.now(), type: String(body.type || '').slice(0, 30) }); save(); }
      return send(res, 200, { ok: true });
    }
    if (m === 'POST' && x[2] === 'submit') {
      if (att.status === 'in_progress') {
        const now = Date.now();
        if (body.answers && typeof body.answers === 'object' && now <= att.endsAt + cfg.GRACE_SECONDS * 1000) {
          for (const o of att.order) { const v = body.answers[o.qid]; if (Number.isInteger(v) && v >= 0 && v < qIndex[o.qid].o.length) att.answers[o.qid] = v; }
        }
        finalize(att, body.reason === 'left' ? 'left' : (now > att.endsAt + cfg.GRACE_SECONDS * 1000 ? 'expired' : 'submitted'), now);
      }
      return send(res, 200, result(att));
    }
  }

  /* --- admin --- */
  if (m === 'POST' && p === '/api/admin/login') {
    if (limited('lg:' + ip(req), 8, 15 * 60e3)) return send(res, 429, { error: 'Too many attempts. Try again in 15 minutes.' });
    const okU = safeEq(hashPw('u:' + String(body.username || '')), USER_HASH), okP = safeEq(hashPw(String(body.password || '')), PW_HASH);
    if (!(okU && okP)) { console.log('Failed admin login from ' + ip(req)); return send(res, 401, { error: 'Wrong username or password.' }); }
    console.log('Admin signed in from ' + ip(req));
    return send(res, 200, { ok: true }, { 'Set-Cookie': cookie(req, makeSession(), cfg.SESSION_HOURS * 3600) });
  }
  if (m === 'POST' && p === '/api/admin/logout') return send(res, 200, { ok: true }, { 'Set-Cookie': cookie(req, '', 0) });
  if (p.startsWith('/api/admin/')) {
    if (!isAdmin(req)) return send(res, 401, { error: 'unauthorized' });
    if (m === 'GET' && p === '/api/admin/me') return send(res, 200, { ok: true });
    if (m === 'POST' && p === '/api/admin/links') {
      if (!levelEnabled(body.level)) return send(res, 400, { error: 'level not available' });
      const token = crypto.randomBytes(24).toString('base64url');
      db.tokens[token] = { level: body.level, created: Date.now(), status: 'unused' }; save();
      const url = baseUrl(req) + '/t/' + token;
      return send(res, 200, { token, level: body.level, levelName: cfg.LEVELS[body.level].name, url, svg: qrSvg(url) });
    }
    if ((x = p.match(/^\/api\/admin\/links\/([^/]+)$/))) {
      const r = db.tokens[x[1]]; if (!r) return send(res, 404, { error: 'not found' });
      if (m === 'GET') return send(res, 200, { status: r.status === 'unused' && tokenState(x[1]) !== 'ready' ? 'expired' : r.status });
      if (m === 'DELETE') { if (r.status === 'unused') { r.status = 'revoked'; save(); } return send(res, 200, { status: r.status }); }
    }
    if (m === 'GET' && p === '/api/admin/results') return send(res, 200, adminRows());
    if (m === 'GET' && p === '/api/admin/results.csv') {
      const rows = adminRows(); const mmss = (s) => (s == null ? '' : Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'));
      const lines = [['Name Surname', 'Phone', 'Level', 'Status', 'Score', 'Total', 'Suggested group', 'Spent time (m:ss)', 'Taken'].map(csvCell).join(',')];
      for (const r of rows) lines.push([r.name, r.phone, r.levelName, r.statusLabel, r.score, r.total, r.group, mmss(r.spentSec), new Date(r.startedAt).toISOString()].map(csvCell).join(','));
      res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="registan-results.csv"', 'Cache-Control': 'no-store' });
      return res.end('\ufeff' + lines.join('\r\n'));
    }
    if ((x = p.match(/^\/api\/admin\/results\/([^/]+)$/)) && m === 'DELETE') {
      if (!db.attempts[x[1]]) return send(res, 404, { error: 'not found' });
      delete db.attempts[x[1]]; save(); return send(res, 200, { ok: true });
    }
  }
  return send(res, 404, { error: 'not found' });
}

/* ---------- static files ---------- */
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
function serveStatic(req, res, url) {
  let p = url.pathname;
  if (p === '/' || p === '/admin' || p.startsWith('/t/')) p = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, p));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    const ext = path.extname(file);
    res.writeHead(200, { 'Content-Type': TYPES[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=3600' });
    res.end(data);
  });
}

const server = http.createServer((req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'");
  let url; try { url = new URL(req.url, 'http://x'); } catch (e) { res.writeHead(400); return res.end(); }
  if (url.pathname.startsWith('/api/')) return api(req, res, url).catch((e) => { console.error(e); send(res, 500, { error: 'server error' }); });
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  serveStatic(req, res, url);
});

/* ---------- background job: finish expired tests, delete old data ---------- */
setInterval(() => {
  const now = Date.now(); let changed = false;
  for (const a of Object.values(db.attempts)) {
    expireIfNeeded(a);
    if (a.status !== 'in_progress' && now - a.finishedAt > cfg.RETENTION_HOURS * HOUR) { delete db.attempts[a.id]; changed = true; }
  }
  for (const [t, r] of Object.entries(db.tokens)) {
    if (now - r.created > 30 * 24 * HOUR) { delete db.tokens[t]; changed = true; }
  }
  if (changed) save();
}, 30e3).unref();

if (require.main === module) server.listen(PORT, () => console.log('Registan LC level test running on port ' + PORT));
module.exports = server;
