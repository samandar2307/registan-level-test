'use strict';
const $ = (s) => document.querySelector(s);
const ls = {
  get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } },
};
async function api(path, opt) {
  opt = opt || {};
  try {
    const r = await fetch(path, { method: opt.method || 'GET', credentials: 'same-origin', headers: opt.body ? { 'Content-Type': 'application/json' } : {}, body: opt.body ? JSON.stringify(opt.body) : undefined, keepalive: !!opt.keepalive });
    let d = null; try { d = await r.json(); } catch (e) { /* not json */ }
    return { ok: r.ok, status: r.status, d };
  } catch (e) { return { ok: false, status: 0, d: null }; }
}
const fmtT = (t) => new Date(t).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
const mmss = (s) => Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');

/* ---------- screens ---------- */
let taking = false;
function go(id) {
  document.querySelectorAll('.screen').forEach((e) => e.classList.toggle('on', e.id === id));
  $('#hn').hidden = id !== 'home';
  window.scrollTo(0, 0);
}
function message(h, p) { $('#mh').textContent = h; $('#mp').textContent = p; go('msg'); }
document.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => { if (!taking) go(b.dataset.go); }));
document.querySelectorAll('[data-sc]').forEach((b) => (b.onclick = () => $('#' + b.dataset.sc).scrollIntoView({ behavior: 'smooth' })));
document.querySelectorAll('[data-ck]').forEach((b) => (b.onclick = () => $('#' + b.dataset.ck).click()));

/* ---------- moving logo strip (runs on the GPU, no jumps) ---------- */
(function () {
  const t = $('#trk'); let an = null;
  t.innerHTML = '<span class="mi"><img alt="" src="/logo-white.png"></span>'.repeat(24);
  function run() {
    const w = Math.round(t.scrollWidth / 2); if (!w) return; if (an) an.cancel();
    an = t.animate([{ transform: 'translate3d(' + (-w) + 'px,0,0)' }, { transform: 'translate3d(0,0,0)' }], { duration: w / 0.06, iterations: Infinity, easing: 'linear' });
  }
  t.querySelectorAll('img').forEach((i) => { if (!i.complete) i.addEventListener('load', run, { once: true }); });
  run(); addEventListener('load', run); addEventListener('resize', run);
})();

/* ---------- home ---------- */
const COLORS = ['#1E8E5A', '#2F6FED', '#E8601F'];
async function loadLevels() {
  const r = await api('/api/levels'); if (!r.ok) return;
  const box = $('#lvcards'); box.innerHTML = '';
  r.d.forEach((l, k) => {
    const c = document.createElement('div'); c.className = 'lc';
    const bar = document.createElement('i'); bar.style.background = COLORS[k % 3];
    const inner = document.createElement('div'); const h = document.createElement('h3'); h.textContent = l.name;
    const e1 = document.createElement('em'); e1.textContent = l.enabled ? l.count + ' questions' : 'Coming soon';
    const e2 = document.createElement('em'); e2.textContent = l.minutes + ' min';
    inner.append(h, e1, e2); c.append(bar, inner); box.append(c);
  });
}
$('#bt').onclick = () => go('code');
$('#ba').onclick = async () => { const r = await api('/api/admin/me'); if (r.ok) showAdmin(); else go('login'); };
$('#cgo').onclick = () => {
  const m = $('#cin').value.match(/[A-Za-z0-9_-]{32}/);
  if (!m) { $('#cerr').textContent = 'Enter the link or the 32-character code from your QR code.'; return; }
  location.href = '/t/' + m[0];
};

/* ---------- test taker: entry form ---------- */
let TOKEN = null, ATT = null, KEY = null, Q = [], ANS = {}, idx = 0, endsAt = 0, offset = 0, timerId = null, STUDENT = '';
const nameOk = (v) => /^\p{L}[\p{L}'’-]+(\s+\p{L}[\p{L}'’-]+)+$/u.test(v.trim());
function fmtPhone(v) {
  let d = v.replace(/\D/g, ''); if (d.startsWith('998')) d = d.slice(3); d = d.slice(0, 9);
  let s = '+998'; if (d.length) s += ' (' + d.slice(0, 2); if (d.length >= 2) s += ')'; if (d.length > 2) s += ' ' + d.slice(2, 5);
  if (d.length > 5) s += '-' + d.slice(5, 7); if (d.length > 7) s += '-' + d.slice(7, 9); return s;
}
$('#p').addEventListener('input', (e) => { e.target.value = fmtPhone(e.target.value); });

async function initTest(token) {
  TOKEN = token;
  const saved = ls.get('att-' + token);
  if (saved) {
    const r = await api('/api/attempt/' + saved.id + '?key=' + encodeURIComponent(saved.key));
    if (r.ok) { ATT = saved.id; KEY = saved.key; if (r.d.finished) return showResult(r.d); return resume(r.d); }
  }
  const r = await api('/api/t/' + token);
  if (r.ok && r.d && r.d.status === 'ready') {
    $('#fl').textContent = r.d.levelName; $('#fq').textContent = r.d.count; $('#fm').textContent = r.d.minutes + ' minutes'; go('start');
  } else if (r.d && r.d.status === 'used') message('This link has already been used', 'Each test link works only once. Please ask Registan LC staff for a new QR code.');
  else if (r.status === 429) message('Too many requests', 'Please wait a minute and try again.');
  else message('This link is not valid', 'The link is wrong or has expired. Please ask Registan LC staff for a new QR code.');
}
function enterFullscreen() { const el = document.documentElement; if (el.requestFullscreen) return el.requestFullscreen().catch(() => {}); }
$('#st').onclick = async () => {
  const nm = $('#n').value.trim(), ph = $('#p').value, o1 = nameOk(nm), o2 = ph.replace(/\D/g, '').length === 12;
  $('#ne').textContent = o1 ? '' : 'Enter your first name and surname, letters only.';
  $('#pe').textContent = o2 ? '' : 'Enter the full number, for example +998 (94) 123-45-67.';
  $('#se').textContent = ''; if (!(o1 && o2)) return;
  $('#st').disabled = true;
  const fs = enterFullscreen(); // must be called from the click
  const r = await api('/api/t/' + TOKEN + '/start', { method: 'POST', body: { name: nm, phone: ph } });
  $('#st').disabled = false;
  if (r.ok) { ATT = r.d.attemptId; KEY = r.d.key; ls.set('att-' + TOKEN, { id: ATT, key: KEY }); await fs; begin(r.d); }
  else if (r.status === 410) { if (document.fullscreenElement) document.exitFullscreen(); message('This link has already been used', 'Each test link works only once. Please ask Registan LC staff for a new QR code.'); }
  else { if (document.fullscreenElement) document.exitFullscreen(); $('#se').textContent = r.status === 400 ? 'Please check your name and phone number.' : 'Could not start the test. Check your internet connection and try again.'; }
};

/* ---------- test ---------- */
function resume(d) {
  const left = Math.max(0, Math.round((d.endsAt - d.serverNow) / 1000)); $('#rt').textContent = mmss(left);
  $('#rc').onclick = async () => { await enterFullscreen(); begin(d); };
  go('resume');
}
function begin(d) {
  Q = d.questions; ANS = d.answers || {}; idx = 0; endsAt = d.endsAt; offset = d.serverNow - Date.now(); STUDENT = d.name || '';
  const firstUnanswered = Q.findIndex((q) => ANS[q.id] === undefined); idx = firstUnanswered < 0 ? 0 : firstUnanswered;
  taking = true; document.body.classList.add('testing'); go('test'); draw();
  clearInterval(timerId); timerId = setInterval(tick, 250); tick();
}
function tick() {
  if (!taking) return;
  const left = Math.max(0, Math.ceil((endsAt - (Date.now() + offset)) / 1000));
  $('#tm').textContent = mmss(left); $('#tm').classList.toggle('low', left < 120);
  const w = left > 0 && left <= 30; $('#wn').hidden = !w; if (w) $('#wn').textContent = left + ' seconds left. Your answers will be submitted automatically.';
  if (left === 0) finish('time');
}
function draw() {
  const q = Q[idx]; $('#cnt').textContent = (idx + 1) + ' / ' + Q.length; $('#pg').style.width = ((idx + 1) / Q.length * 100) + '%';
  $('#ps').hidden = !q.p; $('#ps').textContent = q.p || ''; $('#qt').textContent = q.q; $('#qo').innerHTML = '';
  q.o.forEach((o, k) => {
    const b = document.createElement('button'); b.className = 'opt' + (ANS[q.id] === o.i ? ' sel' : '');
    const s = document.createElement('span'); s.textContent = 'ABCD'[k]; b.append(s, document.createTextNode(o.t));
    b.onclick = () => { ANS[q.id] = o.i; draw(); api('/api/attempt/' + ATT + '/answer', { method: 'POST', body: { key: KEY, qid: q.id, i: o.i }, keepalive: true }); };
    $('#qo').appendChild(b);
  });
  $('#pv').style.visibility = idx ? 'visible' : 'hidden'; $('#nx').textContent = idx === Q.length - 1 ? 'Submit test' : 'Next question';
}
$('#pv').onclick = () => { idx--; draw(); };
$('#nx').onclick = () => {
  if (idx < Q.length - 1) { idx++; draw(); return; }
  const n = Object.keys(ANS).length; $('#mdt').textContent = 'You answered ' + n + ' of ' + Q.length + ' questions. You cannot change your answers after submitting.'; $('#mdl').hidden = false;
};
$('#mn').onclick = () => { $('#mdl').hidden = true; };
$('#my').onclick = () => { $('#mdl').hidden = true; finish('submit'); };

async function finish(reason) {
  if (!taking) return; taking = false; clearInterval(timerId); $('#mdl').hidden = true;
  document.body.classList.remove('testing'); if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  let r = await api('/api/attempt/' + ATT + '/submit', { method: 'POST', body: { key: KEY, reason: reason === 'left' ? 'left' : 'submit', answers: ANS }, keepalive: true });
  if (!r.ok) { await new Promise((ok) => setTimeout(ok, 1500)); r = await api('/api/attempt/' + ATT + '/submit', { method: 'POST', body: { key: KEY, reason: reason === 'left' ? 'left' : 'submit', answers: ANS }, keepalive: true }); }
  if (r.ok) showResult(r.d); else message('Could not send your answers', 'Please tell Registan LC staff. Your saved answers will be counted.');
}
function showResult(d) {
  taking = false; document.body.classList.remove('testing');
  $('#rn').textContent = (d.name || STUDENT || '').split(' ')[0]; $('#rs').textContent = d.score; $('#rtot').textContent = ' / ' + d.total;
  const n = $('#rnote'); n.hidden = d.status === 'submitted';
  if (d.status === 'left') n.textContent = 'Your test ended because you left the test page.'; else if (d.status === 'expired') n.textContent = 'Your time ran out, so your test was submitted automatically.';
  go('result');
}

/* ---------- anti-cheating (all enforced again on the server) ---------- */
function violation(type) { if (taking) api('/api/attempt/' + ATT + '/violation', { method: 'POST', body: { key: KEY, type }, keepalive: true }); }
let unloading = false; // a refresh is not cheating: the test resumes with the same server timer
addEventListener('beforeunload', () => { unloading = true; }); addEventListener('pagehide', () => { unloading = true; });
document.addEventListener('visibilitychange', () => { if (taking && document.hidden && !unloading) { violation('hidden'); finish('left'); } });
addEventListener('blur', () => { if (taking && !unloading) { violation('blur'); finish('left'); } });
document.addEventListener('fullscreenchange', () => { if (taking && !unloading && document.fullscreenEnabled && !document.fullscreenElement) { violation('fullscreen'); finish('left'); } });
['contextmenu', 'copy', 'cut', 'paste', 'dragstart', 'selectstart'].forEach((ev) => document.addEventListener(ev, (e) => { if (taking) e.preventDefault(); }));
document.addEventListener('keydown', (e) => {
  if (!taking) return;
  const k = e.key.toLowerCase(), mod = e.ctrlKey || e.metaKey;
  if (e.key === 'F12' || e.key === 'PrintScreen' || (mod && ['c', 'v', 'x', 'u', 'p', 's', 'a'].includes(k)) || (mod && e.shiftKey && ['i', 'j', 'c'].includes(k))) { e.preventDefault(); violation('key'); }
});

/* ---------- admin ---------- */
let rows = [], pollId = null, linkTok = null, qrPoll = null;
$('#li').onclick = async () => {
  const u = $('#au').value.trim(), p = $('#ap').value; if (!u || !p) { $('#le').textContent = 'Enter your username and password.'; return; }
  $('#li').disabled = true; const r = await api('/api/admin/login', { method: 'POST', body: { username: u, password: p } }); $('#li').disabled = false;
  if (r.ok) { $('#ap').value = ''; $('#le').textContent = ''; showAdmin(); } else $('#le').textContent = (r.d && r.d.error) || 'Could not sign in. Check your connection.';
};
$('#ap').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#li').click(); });
$('#lo').onclick = async () => { await api('/api/admin/logout', { method: 'POST', body: {} }); clearInterval(pollId); clearQR(false); $('#au').value = ''; go('home'); };

async function showAdmin() {
  go('admin');
  const lv = await api('/api/levels');
  if (lv.ok) { $('#lv').innerHTML = ''; lv.d.forEach((l) => { const o = document.createElement('option'); o.value = l.id; o.textContent = l.name + ' · ' + l.minutes + ' min' + (l.enabled ? '' : ' (test not added yet)'); o.disabled = !l.enabled; $('#lv').appendChild(o); }); const first = lv.d.find((l) => l.enabled); if (first) $('#lv').value = first.id; }
  await loadRows(); clearInterval(pollId); pollId = setInterval(() => { if ($('#admin').classList.contains('on')) loadRows(); }, 10000);
}
async function loadRows() {
  const r = await api('/api/admin/results');
  if (r.status === 401) { go('login'); return; } if (!r.ok) return; rows = r.d; renderRows();
}
function renderRows() {
  const q = $('#fs').value.trim().toLowerCase(), st = $('#ff').value; const tb = $('#tb'); tb.innerHTML = '';
  const shown = rows.filter((r) => (!st || r.statusLabel === st) && (!q || (r.name + ' ' + r.phone).toLowerCase().includes(q)));
  shown.forEach((r) => {
    const tr = document.createElement('tr'); const c = (t) => { const td = document.createElement('td'); if (t != null) td.textContent = t; tr.appendChild(td); return td; };
    const n = c(r.name); n.append(document.createElement('br')); const sm = document.createElement('small'); sm.textContent = r.phone; n.append(sm);
    c(r.levelName); const s = c(); const tag = document.createElement('span'); tag.className = 'tag ' + (r.status === 'submitted' ? 'ok' : r.status === 'in_progress' ? 'pend' : 'bad'); tag.textContent = r.statusLabel; s.append(tag);
    c(r.score == null ? '–' : r.score + ' / ' + r.total); c(r.group); c(r.spentSec == null ? '–' : mmss(r.spentSec)); c(fmtT(r.startedAt));
    const d = c(); const b = document.createElement('button'); b.className = 'del'; b.textContent = 'Delete'; b.onclick = async () => { if (confirm('Delete the result of ' + r.name + '?')) { await api('/api/admin/results/' + r.id, { method: 'DELETE' }); loadRows(); } }; d.append(b);
    tb.appendChild(tr);
  });
  $('#empty').hidden = shown.length > 0;
  let sub = 0, end = 0, sum = 0, cnt = 0;
  rows.forEach((r) => { if (r.status === 'submitted') sub++; else if (r.status === 'left' || r.status === 'expired') end++; if (r.score != null && r.total) { sum += r.score / r.total; cnt++; } });
  $('#s1').textContent = rows.length; $('#s2').textContent = sub; $('#s3').textContent = cnt ? Math.round(sum / cnt * 100) + '%' : '–'; $('#s4').textContent = end;
}
$('#fs').addEventListener('input', renderRows); $('#ff').addEventListener('change', renderRows);

/* ---------- admin: one-time QR code ---------- */
let qrMarkup = '';
$('#gen').onclick = async () => {
  $('#gen').disabled = true; const r = await api('/api/admin/links', { method: 'POST', body: { level: $('#lv').value } }); $('#gen').disabled = false;
  if (r.status === 401) { go('login'); return; } if (!r.ok) return;
  if (linkTok) api('/api/admin/links/' + linkTok, { method: 'DELETE' }); // the previous unused QR is cancelled
  linkTok = r.d.token; $('#lu').value = r.d.url; $('#lk').hidden = false; $('#cp').textContent = 'Copy';
  const box = $('#qrb'), chip = $('#qrs'); qrMarkup = r.d.svg; box.innerHTML = qrMarkup; box.classList.remove('used'); chip.className = 'chip'; chip.textContent = 'Waiting for scan'; $('#qrl').textContent = r.d.levelName;
  const c = $('#qrc'); c.hidden = true; void c.offsetWidth; c.hidden = false;
  clearInterval(qrPoll);
  qrPoll = setInterval(async () => {
    const s = await api('/api/admin/links/' + r.d.token); if (!s.ok) return;
    if (s.d.status === 'used') { box.classList.add('used'); chip.className = 'chip used'; chip.textContent = 'Used · QR no longer works'; clearInterval(qrPoll); loadRows(); }
    else if (s.d.status !== 'unused') { chip.className = 'chip used'; chip.textContent = 'Expired'; clearInterval(qrPoll); }
  }, 2000);
};
function clearQR(revoke) {
  clearInterval(qrPoll); if (revoke && linkTok) api('/api/admin/links/' + linkTok, { method: 'DELETE' });
  linkTok = null; $('#lu').value = ''; $('#lk').hidden = true; $('#qrc').hidden = true; $('#qrb').innerHTML = ''; qrMarkup = ''; $('#qov').hidden = true; $('#cp').textContent = 'Copy';
}
$('#clr').onclick = () => clearQR(true);
$('#cp').onclick = async () => { try { await navigator.clipboard.writeText($('#lu').value); $('#cp').textContent = 'Copied'; } catch (e) { $('#lu').select(); } };
function bigQR() { $('#qob').innerHTML = qrMarkup; $('#qol').textContent = $('#qrl').textContent; $('#qov').hidden = false; }
$('#qrb').onclick = bigQR; $('#qrf').onclick = bigQR; $('#qov').onclick = () => { $('#qov').hidden = true; };
addEventListener('keydown', (e) => { if (e.key === 'Escape') $('#qov').hidden = true; });

/* ---------- start ---------- */
(function init() {
  loadLevels();
  const m = location.pathname.match(/^\/t\/([^/]+)\/?$/);
  if (m) { $('#hn').hidden = true; initTest(m[1]); }
  else if (location.pathname === '/admin') $('#ba').click();
})();
