'use strict';
// Edit this file to change time limits, suggested-group rules and retention.
module.exports = {
  // minutes = time limit for the level. A level is enabled only if questions/<id>.json has questions.
  LEVELS: {
    beg: { name: 'Beginner-Elementary', minutes: 20 },
    pre: { name: 'Pre-Intermediate', minutes: 25 },
    int: { name: 'Intermediate', minutes: 30 },
  },
  // Suggested group by percentage correct. The LAST band whose minPct <= result is used.
  // Replace the labels/percentages with the center's real score ranges.
  BANDS: {
    beg: [{ minPct: 0, label: 'Retest / lower group' }, { minPct: 70, label: 'Beginner-Elementary' }, { minPct: 90, label: 'Pre-Intermediate' }],
    pre: [{ minPct: 0, label: 'Retest / lower group' }, { minPct: 70, label: 'Pre-Intermediate' }, { minPct: 90, label: 'Intermediate' }],
    int: [{ minPct: 0, label: 'Retest / lower group' }, { minPct: 70, label: 'Intermediate' }],
  },
  RETENTION_HOURS: 24,   // results are deleted this many hours after the test ends
  TOKEN_TTL_HOURS: 24,   // an unused link/QR expires after this many hours
  GRACE_SECONDS: 3,      // network delay allowed when the timer reaches zero
  SESSION_HOURS: 8,      // admin session length
};
