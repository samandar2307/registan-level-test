# Registan LC – Online Level Test (haqiqiy serverli versiya)

Shahriston Registon LC uchun onlayn daraja aniqlash testi.
Admin bir martalik link va QR kod yaratadi. O‘quvchi QR ni skanerlaydi, ism-familya va telefon kiritadi, vaqt cheklangan testni ishlaydi, natijani ko‘radi.
Natijalar admin panelida 24 soat turadi va keyin avtomatik o‘chadi.

Hech qanday tashqi paket kerak emas (faqat Node.js 18+).

## 1. Kompyuterda sinab ko‘rish

    ADMIN_USER=admin ADMIN_PASSWORD="o‘zingizning-uzun-parolingiz" node server.js

Brauzerda http://localhost:3000 ni oching.
Parol berilmasa, server ishga tushganda vaqtinchalik parol chiqaradi.

## 2. Internetga joylash (Render, bepul reja)

1. Papkani GitHub'ga yuklang (yangi private repository).
2. render.com ga kiring, "New +" > "Web Service" ni tanlang va repository'ni ulang.
3. Sozlamalar: Runtime = Node, Build Command = (bo‘sh qoldiring), Start Command = `node server.js`.
4. "Environment" bo‘limida quyidagilarni kiriting:
   - `ADMIN_USER` – admin login (masalan, registan)
   - `ADMIN_PASSWORD` – uzun, kuchli parol (kamida 12 belgi). Uni hech kimga yubormang.
   - `SESSION_SECRET` – tasodifiy uzun matn (30+ belgi)
   - `PUBLIC_URL` – saytning to‘liq manzili, masalan https://test.registanlc.uz (domen ulangandan keyin)
5. Deploy bosing. Render sizga https://....onrender.com manzil beradi. QR kodlar shu manzilni ishlatadi.
6. O‘z domeningizni ulash: Render > Settings > Custom Domains. Keyin `PUBLIC_URL` ni yangilang.

Muhim:
- Bepul rejada server 15 daqiqa ishlatilmasa "uxlaydi", birinchi ochilish 30-60 soniya olishi mumkin. Test kunlari pullik reja (Starter) tavsiya etiladi.
- Bepul rejada fayllar server qayta ishga tushganda o‘chadi. Natijalar 24 soatdan keyin baribir o‘chadi, lekin kun ichida server qayta ishga tushsa ular yo‘qolishi mumkin. Pullik rejada "Disk" qo‘shib, `DATA_DIR=/var/data` qilib bering.
- Har kuni admin paneldan "Export CSV" bilan natijalarni saqlab qo‘ying, chunki 24 soatdan keyin ular o‘chadi.

## 3. Ishlatish

1. Saytda "Admin" > login va parol bilan kiring.
2. Darajani tanlang va "Create QR code" ni bosing. Link va QR kod chiqadi. QR ichida aynan shu bir martalik link bor.
3. QR ni kattalashtirib (bossangiz to‘liq ekranda ochiladi) o‘quvchiga ko‘rsating.
4. O‘quvchi telefon kamerasi bilan skanerlaydi. Sayt avtomatik ochiladi (hisob yoki login kerak emas): ism-familya, telefon, keyin test.
5. O‘quvchi "Start test" ni bosgan zahoti link ishlatilgan bo‘ladi (QR da "Used" yozuvi chiqadi). Ikkinchi skanerlash "This link has already been used" ko‘rsatadi.
6. "Clear" tugmasi ishlatilmagan QR ni bekor qiladi. Keyingi "Create QR code" yangi QR yaratadi.

## 4. Test qoidalari (serverda majburiy)

- Taymer serverda ishlaydi. Vaqt tugasa test avtomatik topshiriladi ("Time expired").
- Sahifadan chiqish, boshqa tabga o‘tish yoki to‘liq ekrandan chiqish testni tugatadi ("Ended: left page").
- Sahifani yangilash testni qayta boshlamaydi. O‘quvchi shu qurilmada "Continue" bosib davom etadi, vaqt o‘tib turadi.
- Nusxalash, qo‘yish, o‘ng tugma va asosiy klaviatura yorliqlari o‘chirilgan.
- To‘g‘ri javoblar brauzerga hech qachon yuborilmaydi. Hisoblash faqat serverda.
- Savol va javob variantlari har bir o‘quvchi uchun aralashtiriladi.
- Brauzerda 100% himoya bo‘lmaydi (ikkinchi telefon ishlatilishi mumkin). Eng ishonchli yo‘l: testni markaz kompyuterida nazorat ostida topshirtirish.

## 5. Sozlash

`config.js` faylida:
- `minutes` – har bir daraja vaqti (hozir 20 / 25 / 30)
- `BANDS` – tavsiya etilgan guruh uchun foiz oralig‘i. Hozirgi qiymatlar vaqtinchalik, markazning haqiqiy ball oralig‘iga almashtiring.
- `RETENTION_HOURS` – natijalar necha soatdan keyin o‘chadi (24)
- `TOKEN_TTL_HOURS` – ishlatilmagan QR necha soatdan keyin eskiradi (24)

`questions/` papkasida: `beg.json` (Beginner-Elementary), `pre.json` (Pre-Intermediate). Intermediate uchun `questions/int.json` yarating, daraja avtomatik yoqiladi. Format:

    [{"id":"int01","q":"Savol matni","o":["A","B","C","D"],"a":2}]

`a` – to‘g‘ri javobning tartib raqami (0 dan boshlanadi). Matnli savollar uchun `"p":"matn"` qo‘shing, bir xil matnli savollar yonma-yon beriladi.

## 6. Tekshirilishi kerak bo‘lgan savollar

- Beginner-Elementary: javoblar kaliti fayl bilan kelmagan, uni Claude tuzgan. O‘qituvchi tekshirsin, ayniqsa Q29 va Q35.
- Pre-Intermediate: Q16, Q26, Q45, Q48 da kalit yoki variantlar munozarali (bir nechta javob to‘g‘ri bo‘lishi mumkin).

## 7. Xavfsizlik

- Admin paroli faqat serverda tekshiriladi, kodda yozilmagan. 15 daqiqada 8 marta xato kiritilsa bloklanadi.
- Parol `ADMIN_PASSWORD` orqali beriladi va hech qayerda ochiq saqlanmaydi.
- Saytni faqat HTTPS orqali ishlating (Render buni o‘zi beradi).
- QR kod generatori `vendor/QRCode` (MIT litsenziya) ichida, tashqi serverga bog‘liq emas.
